<?php

class Metro_Core
{
    public $sh_tmp_repeater;

    function __construct(){}//end __construct()


}//end class
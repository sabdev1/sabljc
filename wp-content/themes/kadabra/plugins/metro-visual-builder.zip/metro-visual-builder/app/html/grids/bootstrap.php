<?php

$metro_grid_container = 'container';
$metro_basic_row = 'row-fluid';

$metro_basic_grid = array(
    1       =>      'span1',
    2       =>      'span2',
    3       =>      'span3',
    4       =>      'span4',
    5       =>      'span5',
    6       =>      'span6',
    7       =>      'span7',
    8       =>      'span8',
    9       =>      'span9',
    10      =>      'span10',
    11      =>      'span11',
    12      =>      'span12',
);

$metro_mobile_grid = array(
    1       =>      '',
    2       =>      '',
    3       =>      '',
    4       =>      '',
    5       =>      '',
    6       =>      '',
    7       =>      '',
    8       =>      '',
    9       =>      '',
    10      =>      '',
    11      =>      '',
    12      =>      '',
);
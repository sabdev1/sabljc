<?php include(dirname(__FILE__).'/_title.php'); ?>

<script type="text/javascript">
   <?php echo mvb_parse_content_html($content) ?>
</script>
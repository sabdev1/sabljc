<?php

$metro_grid_container = '';
$metro_basic_row = 'row';
$metro_basic_grid = array(
    1       =>      'one columns',
    2       =>      'two columns',
    3       =>      'three columns',
    4       =>      'four columns',
    5       =>      'five columns',
    6       =>      'six columns',
    7       =>      'seven columns',
    8       =>      'eight columns',
    9       =>      'nine columns',
    10      =>      'ten columns',
    11      =>      'eleven columns',
    12      =>      'twelve columns',
);

$metro_mobile_grid = array(
    1       =>      'mobile-one',
    2       =>      'mobile-two',
    3       =>      'mobile-three',
    4       =>      'mobile-four',
    5       =>      'mobile-five',
    6       =>      'mobile-six',
    7       =>      'mobile-seven',
    8       =>      'mobile-eight',
    9       =>      'mobile-nine',
    10      =>      'mobile-ten',
    11      =>      'mobile-eleven',
    12      =>      'mobile-twelve',
);
<?php

$metro_grid_container = '';
$metro_basic_row = 'row';
$metro_basic_grid = array(
    1       =>      'large-1 columns',
    2       =>      'large-2 columns',
    3       =>      'large-3 columns',
    4       =>      'large-4 columns',
    5       =>      'large-5 columns',
    6       =>      'large-6 columns',
    7       =>      'large-7 columns',
    8       =>      'large-8 columns',
    9       =>      'large-9 columns',
    10      =>      'large-10 columns',
    11      =>      'large-11 columns',
    12      =>      'large-12 columns',
);

$metro_mobile_grid = array(
    1       =>      'small-1',
    2       =>      'small-2',
    3       =>      'small-3',
    4       =>      'small-4',
    5       =>      'small-5',
    6       =>      'small-6',
    7       =>      'small-7',
    8       =>      'small-8',
    9       =>      'small-9',
    10      =>      'small-10',
    11      =>      'small-11',
    12      =>      'small-12',
);
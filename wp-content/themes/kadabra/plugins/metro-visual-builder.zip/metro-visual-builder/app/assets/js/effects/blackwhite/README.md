This plug-in can easily convert every colored image (in an html page) into a B&W greyscale image.
Read the plugin API on here http://www.gianlucaguarini.com/canvas-experiments/jQuery.BlackAndWhite/demo.html.

---------
Plugin Showcase
---------

<ul>
	<li><a href="http://teocomi.com/photos/">Teocomi.com</a></li>
	<li><a href="http://www.deejay.it/dj/extra/widget">Deejay.it</a></li>
</ul>

---------

If your want add a new entry please fork this README file
=================

IMPORTANT
=================
the script works only for the images hosted on the same server in which the page is loaded!

THANKS
=================
Thanks to Jeffrey Way for the inspiration ( http://jeffrey-way.com/ )
